from flask_wtf import FlaskForm
from wtforms import StringField, StringField, SubmitField


class SignUpForm(FlaskForm):
    username = StringField("Your name")
    text = StringField("Your message")
    submit = SubmitField("Send message")
# what it is = name of field from flask and what I want to call it