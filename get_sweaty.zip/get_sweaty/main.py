from flask import Flask
from flask import render_template
# render template for connection to html file
from flask import request
# for the form
from forms import SignUpForm
# I called it SignUpForm in forms.py

app = Flask(__name__)
app.config["SECRET_KEY"] = "kerrystieger"
# essential to get our form up and running

@app.route("/home")
def home():
    return render_template("index.html", sunny=True, author="Kerry")
# after the / is what has to be entered to find the page

@app.route("/home/squats")
def squats():
    return render_template("squats.html")

@app.route("/home/legcurls")
def legcurls():
    return render_template("legcurls.html")

@app.route("/home/latpulldown")
def latpulldown():
    return render_template("latpulldown.html")

@app.route("/home/chestpress")
def chestpress():
    return render_template("chestpress.html")

@app.route("/home/bicepscurls")
def bicepscurls():
    return render_template("bicepscurls.html")

@app.route("/home/tricepspulldown")
def tricepspulldown():
    return render_template("tricepspulldown.html")



@app.route("/nutrition")
def nutrition():
    return render_template("nutrition.html")


@app.route("/contact", methods=["GET", "POST"])
def contact():
    form = SignUpForm()
    if form.is_submitted():
        result = request.form
        return render_template("user.html", result=result)
        # when it is submitted the user is taken to the user html sight
    return render_template("contact.html", form=form)
# form = form, form comes from forms.py there we called things in curly brackets form.username.label


if __name__ == "__main__":
    app.run(debug=True, port=5000)

